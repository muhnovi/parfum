'use client'

import { Review, useReviews } from '@/context/ReviewsContext'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import Link from 'next/link'
import { Trash2, ChevronRight } from 'lucide-react'

interface ReviewCardProps {
  review: Review
}

export function ReviewCard({ review }: ReviewCardProps) {
  const { deleteReview } = useReviews()

  const handleDelete = (e: React.MouseEvent) => {
    e.preventDefault()
    if (confirm('Are you sure you want to delete this review?')) {
      deleteReview(review.id)
    }
  }

  return (
    <Link href={`/review/${review.id}`}>
      <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300 cursor-pointer h-full flex flex-col bg-card border border-border group">
        {/* Image Container */}
        <div className="relative w-full aspect-square overflow-hidden bg-muted">
          <img
            src={review.image}
            alt={review.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        </div>

        {/* Content Container */}
        <div className="flex-1 p-4 flex flex-col">
          {/* Type Badge and Name */}
          <div className="mb-3">
            <div className="mb-2">
              {review.fragranceType === 'pagi' && (
                <span className="inline-block px-3 py-1 text-xs font-semibold rounded-full bg-accent text-accent-foreground">
                  ☀️ Parfum Siang
                </span>
              )}
              {review.fragranceType === 'malam' && (
                <span className="inline-block px-3 py-1 text-xs font-semibold rounded-full bg-primary text-primary-foreground">
                  🌙 Parfum Malam
                </span>
              )}
              {review.fragranceType === 'versatile' && (
                <span className="inline-block px-3 py-1 text-xs font-semibold rounded-full bg-secondary text-secondary-foreground">
                  ✨ Versatile
                </span>
              )}
            </div>
            <h3 className="text-lg font-bold text-foreground line-clamp-2 mb-2">
              {review.name}
            </h3>
            <div className="flex items-center gap-2">
              <div className="flex gap-1">
                {[...Array(5)].map((_, i) => (
                  <span
                    key={i}
                    className={`text-lg ${
                      i < Math.round(review.rating)
                        ? 'text-accent'
                        : 'text-muted'
                    }`}
                  >
                    ★
                  </span>
                ))}
              </div>
              <span className="text-sm font-semibold text-foreground">
                {review.rating.toFixed(1)}
              </span>
            </div>
          </div>

          {/* Description */}
          <p className="text-sm text-muted-foreground line-clamp-3 mb-4 flex-1">
            {review.description}
          </p>

          {/* Username and Date */}
          <div className="flex items-center justify-between text-xs text-muted-foreground mb-4">
            <span className="font-medium">@{review.username}</span>
            <span>
              {new Date(review.createdAt).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
              })}
            </span>
          </div>

          {/* Actions */}
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              className="flex-1 text-foreground border-border hover:bg-muted"
              asChild
            >
              <span className="flex items-center justify-center gap-1">
                View <ChevronRight className="w-4 h-4" />
              </span>
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleDelete}
              className="text-destructive border-destructive hover:bg-destructive/10"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </Card>
    </Link>
  )
}
