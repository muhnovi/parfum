'use client'

import { useState } from 'react'
import { useReviews, FragranceType } from '@/context/ReviewsContext'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'

interface ReviewFormProps {
  onSuccess?: () => void
  isModal?: boolean
}

export function ReviewForm({ onSuccess, isModal = false }: ReviewFormProps) {
  const { addReview } = useReviews()
  const [username, setUsername] = useState('')
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [rating, setRating] = useState(4)
  const [image, setImage] = useState<string>('')
  const [fragranceType, setFragranceType] = useState<FragranceType>('versatile')
  const [isLoading, setIsLoading] = useState(false)

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setImage(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!username.trim() || !name.trim() || !description.trim() || !image) {
      alert('Please fill all fields and select an image')
      return
    }

    setIsLoading(true)
    try {
      addReview({
        username: username.trim(),
        name: name.trim(),
        description: description.trim(),
        rating: parseFloat(rating.toString()),
        image,
        fragranceType,
      })
      setUsername('')
      setName('')
      setDescription('')
      setRating(4)
      setImage('')
      setFragranceType('versatile')
      onSuccess?.()
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-2xl mx-auto p-6 bg-card border border-border">
      <h2 className="text-2xl font-bold text-foreground mb-6">Add New Review</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Username */}
        <div className="space-y-2">
          <label className="block text-sm font-semibold text-foreground">
            Username
          </label>
          <Input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="e.g., fragrance_lover"
            className="w-full"
            required
          />
        </div>

        {/* Image Upload */}
        <div className="space-y-3">
          <label className="block text-sm font-semibold text-foreground">
            Perfume Image
          </label>
          <div className="relative">
            <input
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="hidden"
              id="image-input"
              required
            />
            <label
              htmlFor="image-input"
              className="flex items-center justify-center w-full h-40 border-2 border-dashed border-border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors"
            >
              {image ? (
                <img
                  src={image}
                  alt="Preview"
                  className="w-full h-full object-cover rounded-md"
                />
              ) : (
                <div className="text-center">
                  <p className="text-muted-foreground">Click to upload image</p>
                  <p className="text-xs text-muted-foreground mt-1">or drag and drop</p>
                </div>
              )}
            </label>
          </div>
        </div>

        {/* Fragrance Type */}
        <div className="space-y-2">
          <label className="block text-sm font-semibold text-foreground">
            Fragrance Type
          </label>
          <div className="grid grid-cols-3 gap-3">
            {[
              { value: 'pagi' as FragranceType, label: 'Parfum Siang', emoji: '☀️' },
              { value: 'malam' as FragranceType, label: 'Parfum Malam', emoji: '🌙' },
              { value: 'versatile' as FragranceType, label: 'Versatile', emoji: '✨' },
            ].map((option) => (
              <button
                key={option.value}
                type="button"
                onClick={() => setFragranceType(option.value)}
                className={`p-3 rounded-lg border-2 transition-all ${
                  fragranceType === option.value
                    ? 'border-primary bg-primary/10 text-foreground'
                    : 'border-border bg-background text-muted-foreground hover:border-primary/50'
                }`}
              >
                <div className="text-2xl mb-1">{option.emoji}</div>
                <div className="text-xs font-medium">{option.label}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Name */}
        <div className="space-y-2">
          <label className="block text-sm font-semibold text-foreground">
            Perfume Name
          </label>
          <Input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g., Dior Sauvage"
            className="w-full"
            required
          />
        </div>

        {/* Description */}
        <div className="space-y-2">
          <label className="block text-sm font-semibold text-foreground">
            Description
          </label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Share your thoughts about this perfume..."
            className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent"
            rows={5}
            required
          />
        </div>

        {/* Rating */}
        <div className="space-y-3">
          <label className="block text-sm font-semibold text-foreground">
            Rating: {rating.toFixed(1)}/5.0
          </label>
          <input
            type="range"
            min="0"
            max="5"
            step="0.1"
            value={rating}
            onChange={(e) => setRating(parseFloat(e.target.value))}
            className="w-full h-2 bg-border rounded-lg appearance-none cursor-pointer"
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>0</span>
            <span>2.5</span>
            <span>5</span>
          </div>
        </div>

        {/* Submit Button */}
        <Button
          type="submit"
          disabled={isLoading}
          className="w-full bg-primary text-primary-foreground hover:opacity-90 disabled:opacity-50"
        >
          {isLoading ? 'Publishing...' : 'Publish Review'}
        </Button>
      </form>
    </Card>
  )
}
