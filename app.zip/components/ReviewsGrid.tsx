'use client'

import { useState } from 'react'
import { useReviews, FragranceType } from '@/context/ReviewsContext'
import { ReviewCard } from './ReviewCard'
import { Empty } from '@/components/ui/empty'
import { Input } from '@/components/ui/input'
import { Search, X } from 'lucide-react'

export function ReviewsGrid() {
  const { reviews } = useReviews()
  const [selectedType, setSelectedType] = useState<FragranceType | 'all'>('all')
  const [searchQuery, setSearchQuery] = useState('')

  const filteredReviews = reviews
    .filter(review => selectedType === 'all' ? true : review.fragranceType === selectedType)
    .filter(review => 
      searchQuery.trim() === '' 
        ? true 
        : review.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          review.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          review.username.toLowerCase().includes(searchQuery.toLowerCase())
    )

  const filterOptions = [
    { value: 'all' as const, label: 'Semua', emoji: '🌸' },
    { value: 'pagi' as FragranceType, label: 'Parfum Siang', emoji: '☀️' },
    { value: 'malam' as FragranceType, label: 'Parfum Malam', emoji: '🌙' },
    { value: 'versatile' as FragranceType, label: 'Versatile', emoji: '✨' },
  ]

  if (reviews.length === 0) {
    return (
      <Empty
        icon="🌸"
        title="No reviews yet"
        description="Start by adding your first perfume review to share your fragrance experience with others."
      />
    )
  }

  return (
    <div className="w-full space-y-6">
      {/* Search Input */}
      <div className="relative">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none" />
          <Input
            type="text"
            placeholder="Cari nama parfum, deskripsi, atau username..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 pr-10 py-2.5"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Filter Buttons */}
      <div className="flex flex-wrap gap-2 pb-4 border-b border-border">
        {filterOptions.map((option) => (
          <button
            key={option.value}
            onClick={() => setSelectedType(option.value)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
              selectedType === option.value
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted text-muted-foreground hover:bg-muted/80'
            }`}
          >
            <span className="mr-2">{option.emoji}</span>
            {option.label}
            {option.value !== 'all' && (
              <span className="ml-2 text-xs">({reviews.filter(r => r.fragranceType === option.value).length})</span>
            )}
          </button>
        ))}
      </div>

      {/* Reviews Grid */}
      {filteredReviews.length === 0 ? (
        <Empty
          icon="🔍"
          title="No reviews found"
          description={
            searchQuery
              ? `Tidak ada parfum yang cocok dengan "${searchQuery}".`
              : `No perfume reviews available for ${filterOptions.find(o => o.value === selectedType)?.label}.`
          }
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredReviews.map((review) => (
            <ReviewCard key={review.id} review={review} />
          ))}
        </div>
      )}
    </div>
  )
}
