'use client'

import React, { createContext, useContext, useState, useCallback } from 'react'

export type FragranceType = 'pagi' | 'malam' | 'versatile'

export interface Review {
  id: string
  name: string
  description: string
  image: string
  rating: number
  fragranceType: FragranceType
  username: string
  createdAt: Date
}

interface ReviewsContextType {
  reviews: Review[]
  addReview: (review: Omit<Review, 'id' | 'createdAt'>) => void
  deleteReview: (id: string) => void
  updateReview: (id: string, review: Omit<Review, 'id' | 'createdAt'>) => void
}

const ReviewsContext = createContext<ReviewsContextType | undefined>(undefined)

export function ReviewsProvider({ children }: { children: React.ReactNode }) {
  const [reviews, setReviews] = useState<Review[]>([
    {
      id: '1',
      name: 'Dior Sauvage',
      description: 'A fresh and spicy fragrance with ambroxan. Perfect for everyday wear with a lasting projection.',
      image: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22200%22 height=%22300%22%3E%3Crect fill=%22%23f0e6d2%22 width=%22200%22 height=%22300%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2224%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22 fill=%22%23333%22%3EDior Sauvage%3C/text%3E%3C/svg%3E',
      rating: 4.8,
      fragranceType: 'versatile',
      username: 'fragrance_lover',
      createdAt: new Date('2024-01-15'),
    },
    {
      id: '2',
      name: 'Creed Aventus',
      description: 'Luxurious and powerful. A masterpiece with pineapple and birch notes. Excellent longevity.',
      image: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22200%22 height=%22300%22%3E%3Crect fill=%22%23d4a574%22 width=%22200%22 height=%22300%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2224%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22 fill=%22%23fff%22%3ECreed Aventus%3C/text%3E%3C/svg%3E',
      rating: 5.0,
      fragranceType: 'pagi',
      username: 'perfume_connoisseur',
      createdAt: new Date('2024-02-20'),
    },
  ])

  const addReview = useCallback(
    (review: Omit<Review, 'id' | 'createdAt'>) => {
      const newReview: Review = {
        ...review,
        id: Date.now().toString(),
        createdAt: new Date(),
      }
      setReviews((prev) => [newReview, ...prev])
    },
    []
  )

  const deleteReview = useCallback((id: string) => {
    setReviews((prev) => prev.filter((review) => review.id !== id))
  }, [])

  const updateReview = useCallback(
    (id: string, review: Omit<Review, 'id' | 'createdAt'>) => {
      setReviews((prev) =>
        prev.map((r) => (r.id === id ? { ...r, ...review } : r))
      )
    },
    []
  )

  return (
    <ReviewsContext.Provider value={{ reviews, addReview, deleteReview, updateReview }}>
      {children}
    </ReviewsContext.Provider>
  )
}

export function useReviews() {
  const context = useContext(ReviewsContext)
  if (!context) {
    throw new Error('useReviews must be used within ReviewsProvider')
  }
  return context
}
